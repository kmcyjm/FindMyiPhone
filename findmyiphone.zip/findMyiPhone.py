import boto3
import os
from base64 import b64decode
from pyicloud import PyiCloudService

my_password_encrypted = os.environ['MY_PASSWORD']
my_wife_password_encrypted = os.environ['MY_WIFE_PASSWORD']
my_email_encrypted = os.environ['MY_EMAIL']
my_wife_email_encrypted = os.environ['MY_WIFE_EMAIL']
my_iot_button_encrypted = os.environ['IOT_BUTTON_SERIAL_NUM']

# Decrypt code should run once and variables stored outside of the function
# handler so that these are decrypted once per container

kms = boto3.client('kms')

my_email_decrypted = kms.decrypt(CiphertextBlob=b64decode(my_email_encrypted))['Plaintext']
my_password_decrypted = kms.decrypt(CiphertextBlob=b64decode(my_password_encrypted))['Plaintext']
my_wife_email_decrypted = kms.decrypt(CiphertextBlob=b64decode(my_wife_email_encrypted))['Plaintext']
my_wife_password_decrypted = kms.decrypt(CiphertextBlob=b64decode(my_wife_password_encrypted))['Plaintext']
my_iot_button_decrypted = kms.decrypt(CiphertextBlob=b64decode(my_iot_button_encrypted))['Plaintext']

def find_my_iphone(event, context):

    print(event)

    if event['serialNumber'] == my_iot_button_decrypted.decode('utf8') and event['clickType'] == 'SINGLE':
        api = PyiCloudService(my_wife_email_decrypted.decode('utf8'), my_wife_password_decrypted.decode('utf8'))
        api.devices[1].play_sound()

    elif event['serialNumber'] == my_iot_button_decrypted.decode('utf8') and event['clickType'] == 'DOUBLE':

        api = PyiCloudService(my_email_decrypted.decode('utf8'), my_password_decrypted.decode('utf8'))
        api.devices[1].play_sound()
